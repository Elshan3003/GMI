package com.GMIBank.utils;

import org.openqa.selenium.WebDriver;

public class Base {

	protected static WebDriver driver;

}
