package com.GMIBank.stepDefinitions;


import org.openqa.selenium.WebElement;


import com.GMIBank.pages.GmiRegistirationPage;
import com.GMIBank.pages.GmiSignInPage;
import com.GMIBank.utils.Base;
import com.GMIBank.utils.Config;


import cucumber.api.java.en.*;
import static org.junit.Assert.*;




public class PasswordLevelStepDefinitions extends Base {
	GmiSignInPage signInPage=new GmiSignInPage();
	GmiRegistirationPage registerPage=new GmiRegistirationPage();
	
	@Given("^User open homepage of GMIBANK application$")
	public void user_open_homepage_of_GMIBANK_application() throws Throwable {
		driver.get(Config.getProperty("URL"));
		
		
	}

	@Given("^User clicks on \"([^\"]*)\" in account menu$")
	public void user_clicks_on_in_account_menu(String arg1) throws Throwable {
			signInPage.accountMenu.click();
			registerPage.registerButton.click();		
			assertTrue(registerPage.SSN.isDisplayed());
	
	}
	
	@And("^User enter \"([^\"]*)\" to password field$")
	public void user_enter_to_password_field(String password) throws Throwable {
		    registerPage.firstPasword.sendKeys(password);
	
	}

	@Then("^User checks if level chart is \"([^\"]*)\"$")
	public void user_checks_if_level_chart_is(String expectedChartColor) throws Throwable {
		
		int counter=0;

		for (WebElement element : registerPage.passwordLevelChart) {
			String rgb=element.getAttribute("style");
			if(rgb.contains("255")){
				counter++;
			}
		}

 // color is determined based on count of 255 in chart
		String color="";
		switch (counter) {
		case 1:
			color="red";
			break;
		case 2:
			color="orange";
			break;
		case 4:
			color="green";
			break;
		default:
			break;
		}
		
		
		assertEquals(expectedChartColor, color);
		
	}

	

}
