package com.GMIBank.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.GMIBank.utils.Base;

public class GmiRegistirationPage extends Base {
	
	public GmiRegistirationPage() {
        PageFactory.initElements(driver,this);
    }
	
	  @FindBy(xpath ="//*[text()='Register']")
	    public WebElement registerButton;
	  
	  @FindBy(xpath ="//*[text()='SSN']")
	    public WebElement SSN;
	  
	  @FindBy(id ="firstPassword")
	    public WebElement firstPasword;
	  
	  @FindBy(xpath ="//*[@id='strengthBar']/li")
	    public List<WebElement> passwordLevelChart;
	
}
